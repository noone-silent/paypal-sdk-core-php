<?php
namespace PayPal\PayPalAPI;

use PayPal\EBLBaseComponents\AbstractResponseType;

/**
 *
 */
class CreateMobilePaymentResponseType extends AbstractResponseType
{

}
