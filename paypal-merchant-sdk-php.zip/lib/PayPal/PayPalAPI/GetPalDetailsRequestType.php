<?php
namespace PayPal\PayPalAPI;

use PayPal\EBLBaseComponents\AbstractRequestType;

/**
 *
 */
class GetPalDetailsRequestType extends AbstractRequestType
{

}
